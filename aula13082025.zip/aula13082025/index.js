const a = 1
let b = 3

console.log(a + b)
console.log(7 + 9)