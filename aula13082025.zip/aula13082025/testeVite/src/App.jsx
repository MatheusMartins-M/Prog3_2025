import { useState } from 'react'
import reactLogo from './assets/react.svg'
import youtubeLogo from './assets/youtube.svg'
import nodeLogo from './assets/nodeJS.svg'
import viteLogo from '/vite.svg'
import gitLogo from './assets/git.svg'
import './App.css'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <div>
        <a href="https://vite.dev" target="_blank">
          <img src={viteLogo} className="logo" alt="Vite logo" />
        </a>
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
        <a href="https://www.youtube.com/" target='_blank'>
          <img src={youtubeLogo} className='logo youtube' alt='Youtube logo' />
        </a>
        <a href="https://nodejs.org/pt" target='_blank'>
          <img src={nodeLogo} className='logo node' alt='Node logo' />
        </a>
        <a href="https://comandosgit.github.io/" target='_blank'>
          <img src={gitLogo} className='logo git' alt='Git logo' />
        </a>
      </div>
      <h1>Vite + React + Youtube + Node JS + Git</h1>
      <div className="card">
        <button onClick={() => setCount((count) => count + 1)}>Add 1</button>
        <button onClick={() => setCount((count) => count + 10)}>Add 10</button>
        <button onClick={() => setCount((count) => count - 1)}>Sub 1</button>
        <button onClick={() => setCount((count) => count - 10)}>Sub 10</button>
        <p>
          count is {count}
        </p>
      </div>
      <p className="read-the-docs">
        Click on the logos to learn more
      </p>
    </>
  )
}

export default App
